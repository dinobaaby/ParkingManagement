﻿
namespace ParkingManagement.Constracts.Authentication
{
    public sealed record RefreshTokenRequest(String UserId, string RefreshToken);
    
}
