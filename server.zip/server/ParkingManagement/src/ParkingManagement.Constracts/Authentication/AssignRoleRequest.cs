﻿

namespace ParkingManagement.Constracts.Authentication
{
    public class AssignRoleRequest
    {
        public string Email { get; set; } = null!;
        public string RoleName { get; set; } = null!;

    }
}
