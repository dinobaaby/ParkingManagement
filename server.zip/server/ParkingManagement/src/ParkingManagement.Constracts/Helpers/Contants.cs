﻿

namespace ParkingManagement.Constracts.Helpers
{
    public class Contants
    {
    }

    public enum ROLES
    {
        ADMIN,
        MANAGER,
        CLIENT
    }
}
