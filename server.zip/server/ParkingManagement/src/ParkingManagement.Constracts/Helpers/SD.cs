﻿

namespace ParkingManagement.Constracts.Helpers
{
    public class SD
    {
        public const string APIURL = "https://localhost:4000/api/";
    }
}
